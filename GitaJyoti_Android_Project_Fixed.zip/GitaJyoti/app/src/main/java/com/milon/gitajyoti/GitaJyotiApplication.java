package com.milon.gitajyoti;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.util.Date;

/**
 * Loads an AdMob "App Open" ad and shows it whenever the app comes to the
 * foreground (cold start or returning from background) — but not while the
 * user is inside a fullscreen ad already, and not on the very first frame
 * before anything has loaded.
 *
 * ⚠️ IMPORTANT: Replace TEST_AD_UNIT_ID below with your REAL App Open ad
 * unit ID from AdMob (Ad units > App Open > copy the ID that looks like
 * ca-app-pub-6847744858575721/XXXXXXXXXX) once it's ready. Using the real
 * ID with your own device before the app is published/approved can get
 * your AdMob account flagged for invalid traffic — always test with the
 * TEST ID first, and only switch to the real ID for the Play Store release.
 */
public class GitaJyotiApplication extends Application implements DefaultLifecycleObserver {

    private static final String TAG = "GitaJyotiApp";

    // Google's official public TEST ad unit ID for App Open ads — safe to click/test anytime.
    private static final String TEST_AD_UNIT_ID = "ca-app-pub-3940256099942544/9257395921";

    // Your real App Open Ad Unit ID from AdMob (Gita Jyoti > Ad units > GitaJyoti_AppOpen).
    private static final String REAL_AD_UNIT_ID = "ca-app-pub-6847744858575721/3572008521";

    // ⚠️ Keep this as TEST_AD_UNIT_ID while YOU are personally installing/opening the app
    // to check things — repeatedly viewing your own real ad unit can get flagged as
    // invalid traffic by AdMob. Switch this to REAL_AD_UNIT_ID only for the build you
    // actually upload to the Play Store / share with real users.
    private static final String AD_UNIT_ID = TEST_AD_UNIT_ID;

    private AppOpenAd appOpenAd = null;
    private boolean isLoadingAd = false;
    private boolean isShowingAd = false;
    private long loadTime = 0;
    private Activity currentActivity;

    @Override
    public void onCreate() {
        super.onCreate();

        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            java.io.StringWriter sw = new java.io.StringWriter();
            throwable.printStackTrace(new java.io.PrintWriter(sw));
            android.content.Intent intent = new android.content.Intent(this, CrashActivity.class);
            intent.putExtra("error", sw.toString());
            intent.setFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        });

        MobileAds.initialize(this, initializationStatus -> {
            Log.d(TAG, "MobileAds initialized");
        });

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(@NonNull Activity activity, Bundle savedInstanceState) {}

            @Override
            public void onActivityStarted(@NonNull Activity activity) {
                currentActivity = activity;
            }

            @Override
            public void onActivityResumed(@NonNull Activity activity) {
                currentActivity = activity;
            }

            @Override
            public void onActivityPaused(@NonNull Activity activity) {}

            @Override
            public void onActivityStopped(@NonNull Activity activity) {}

            @Override
            public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}

            @Override
            public void onActivityDestroyed(@NonNull Activity activity) {
                if (currentActivity == activity) currentActivity = null;
            }
        });

        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);

        loadAd();
    }

    /** Called by ProcessLifecycleOwner when the app moves to the foreground. */
    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        showAdIfAvailable();
    }

    private void loadAd() {
        if (isLoadingAd || isAdAvailable()) return;
        isLoadingAd = true;

        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(this, AD_UNIT_ID, request,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        appOpenAd = ad;
                        isLoadingAd = false;
                        loadTime = new Date().getTime();
                        Log.d(TAG, "App Open ad loaded");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull com.google.android.gms.ads.LoadAdError loadAdError) {
                        isLoadingAd = false;
                        Log.d(TAG, "App Open ad failed to load: " + loadAdError.getMessage());
                    }
                });
    }

    private boolean isAdAvailable() {
        // Ads expire after ~4 hours; discard stale ones instead of showing an error.
        long fourHoursInMillis = 4 * 60 * 60 * 1000;
        return appOpenAd != null
                && (new Date().getTime() - loadTime) < fourHoursInMillis;
    }

    private void showAdIfAvailable() {
        if (isShowingAd) return;

        if (!isAdAvailable()) {
            loadAd();
            return;
        }
        if (currentActivity == null) return;

        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                appOpenAd = null;
                isShowingAd = false;
                loadAd();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                appOpenAd = null;
                isShowingAd = false;
                loadAd();
            }

            @Override
            public void onAdShowedFullScreenContent() {
                isShowingAd = true;
            }
        });

        appOpenAd.show(currentActivity);
    }
}
