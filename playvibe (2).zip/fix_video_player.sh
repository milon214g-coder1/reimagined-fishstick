#!/bin/bash
sed -i 's/ExoPlayer.Builder(context).build()/ExoPlayer.Builder(context).setSeekForwardIncrementMs(10000).setSeekBackIncrementMs(10000).build()/' app/src/main/java/com/example/VideoPlayerView.kt
