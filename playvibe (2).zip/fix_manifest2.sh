#!/bin/bash
sed -i '/<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" \/>/a \    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" \/>' app/src/main/AndroidManifest.xml
