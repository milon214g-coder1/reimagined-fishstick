package com.example

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

data class Post(
    val id: String = "",
    val imageUrl: String = "",
    val caption: String = "",
    val uploaderId: String = "",
    val timestamp: Long = 0,
    val likeCount: Int = 0,
    val isLiked: Boolean = false,
    val userProfile: UserProfile = UserProfile()
)

data class UserProfile(
    val id: String = "",
    val name: String = "",
    val handle: String = "",
    val profileImageUrl: String = "",
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val isFollowing: Boolean = false,
    val bio: String = ""
)

data class Comment(
    val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorProfileUrl: String = "",
    val text: String = "",
    val timestamp: Long = 0
)

data class Notification(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val timestamp: Long = 0,
    val imageUrl: String = ""
)

val mockPosts = mutableStateListOf<Post>()
val mockUsers = mutableStateListOf<UserProfile>()
var currentUserProfile by mutableStateOf(UserProfile(id = "my_id", name = "Guest"))
val mockNotifications = mutableStateListOf<Notification>()
