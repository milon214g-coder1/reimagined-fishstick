package com.example

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PicConnectApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun PicConnectApp() {
    var isAuthenticated by remember { mutableStateOf(false) }
    var isCheckingAuth by remember { mutableStateOf(true) }

    val permissionsToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        listOf(android.Manifest.permission.READ_MEDIA_IMAGES, android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        listOf(android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)
    } else {
        listOf(android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)
    }
    
    val permissionsState = rememberMultiplePermissionsState(permissionsToRequest)
    var showPermissionRationale by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
        }
    }
    
    if (!permissionsState.allPermissionsGranted && permissionsState.shouldShowRationale) {
        showPermissionRationale = true
    }

    DisposableEffect(Unit) {
        val listener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { auth ->
            isAuthenticated = auth.currentUser != null
            isCheckingAuth = false
            if (isAuthenticated) {
                FirebaseManager.initFirebaseData()
            }
        }
        try {
            FirebaseManager.auth.addAuthStateListener(listener)
        } catch (e: Exception) {
            isCheckingAuth = false
        }
        
        onDispose {
            try {
                FirebaseManager.auth.removeAuthStateListener(listener)
            } catch (e: Exception) {}
        }
    }

    if (isCheckingAuth) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (!isAuthenticated) {
        AuthScreen(onAuthSuccess = { isAuthenticated = true })
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val myId = FirebaseManager.auth.currentUser?.uid ?: ""
    LaunchedEffect(myId) {
        if (myId.isNotEmpty()) {
            FirebaseManager.firestore.collection("calls")
                .whereEqualTo("receiverId", myId)
                .whereEqualTo("status", "calling")
                .addSnapshotListener { snap, _ ->
                    if (snap != null && snap.documents.isNotEmpty()) {
                        val callDoc = snap.documents.first()
                        val callerId = callDoc.getString("callerId") ?: ""
                        val isVideo = callDoc.getBoolean("isVideo") ?: false
                        val callId = callDoc.id
                        navController.navigate("call_incoming/$callerId/$isVideo/$callId")
                    }
                }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentRoute != "call/{peerId}/{isVideo}" && currentRoute != "call_incoming/{peerId}/{isVideo}/{callId}") {
                TopAppBar(
                    title = { PlayVibeLogo() },
                    actions = {
                        IconButton(onClick = { navController.navigate("notifications") }) {
                            Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground,
                        actionIconContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
        },
        bottomBar = {
            if (currentRoute == Screen.Home.route || currentRoute == Screen.Upload.route || currentRoute == Screen.You.route) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.onBackground
                ) {
                    BottomNavScreens.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.label) },
                            label = { Text(screen.label) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(onUserClick = { userId ->
                    navController.navigate("user/$userId")
                })
            }
            composable(Screen.Upload.route) {
                CreatePostScreen(onPostCreated = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(navController.graph.startDestinationId)
                    }
                })
            }
            composable(Screen.You.route) { 
                UserProfileScreen(
                    userId = myId,
                    onNavigateUp = { navController.navigateUp() },
                    onMessageClick = { }, // Should not be called for own profile
                    onSettingsClick = { navController.navigate("settings") },
                    onEditProfileClick = { navController.navigate("edit_profile") }
                ) 
            }
            composable("user/{userId}") { backStackEntry ->
                val userId = backStackEntry.arguments?.getString("userId") ?: ""
                UserProfileScreen(
                    userId = userId,
                    onNavigateUp = { navController.navigateUp() },
                    onMessageClick = { navController.navigate("chat/$userId") },
                    onSettingsClick = { },
                    onEditProfileClick = { }
                )
            }
            composable("settings") {
                SettingsScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("notifications") {
                NotificationsScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("call/{peerId}/{isVideo}") { backStackEntry ->
                val peerId = backStackEntry.arguments?.getString("peerId") ?: ""
                val isVideo = backStackEntry.arguments?.getString("isVideo")?.toBoolean() ?: false
                CallScreen(
                    peerId = peerId,
                    isVideo = isVideo,
                    isIncoming = false,
                    callId = null,
                    onEndCall = { navController.navigateUp() }
                )
            }
            composable("call_incoming/{peerId}/{isVideo}/{callId}") { backStackEntry ->
                val peerId = backStackEntry.arguments?.getString("peerId") ?: ""
                val isVideo = backStackEntry.arguments?.getString("isVideo")?.toBoolean() ?: false
                val callId = backStackEntry.arguments?.getString("callId")
                CallScreen(
                    peerId = peerId,
                    isVideo = isVideo,
                    isIncoming = true,
                    callId = callId,
                    onEndCall = { navController.navigateUp() }
                )
            }
            composable("chat/{channelId}") { backStackEntry ->
                val channelId = backStackEntry.arguments?.getString("channelId") ?: ""
                ChatScreen(
                    channelId = channelId,
                    onNavigateUp = { navController.navigateUp() },
                    onCallClick = { isVideo ->
                        navController.navigate("call/$channelId/$isVideo")
                    }
                )
            }
            composable("edit_profile") {
                EditProfileScreen(onNavigateUp = { navController.navigateUp() })
            }
        }
        
        if (showPermissionRationale) {
            AlertDialog(
                onDismissRequest = { showPermissionRationale = false },
                title = { Text("Permission Required") },
                text = { Text("Permissions are needed to upload photos and make calls.") },
                confirmButton = {
                    TextButton(onClick = { 
                        showPermissionRationale = false
                        permissionsState.launchMultiplePermissionRequest()
                    }) {
                        Text("Grant")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showPermissionRationale = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
