package com.example

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.util.UUID

object FirebaseManager {
    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    val storage: FirebaseStorage by lazy { FirebaseStorage.getInstance() }
    
    private var isInitialized = false

    fun listenToAuthState(onAuthStateChanged: (FirebaseUser?) -> Unit) {
        auth.addAuthStateListener { firebaseAuth ->
            onAuthStateChanged(firebaseAuth.currentUser)
        }
    }

    suspend fun signInAnonymously(): Result<FirebaseUser> {
        return try {
            val result = auth.signInAnonymously().await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createUserDocument(user: FirebaseUser, displayName: String = "Guest", phone: String = "") {
        try {
            val userRef = firestore.collection("users").document(user.uid)
            val snapshot = userRef.get().await()
            if (!snapshot.exists()) {
                val userData = mapOf(
                    "name" to displayName,
                    "handle" to "@${displayName.replace(" ", "").lowercase()}${user.uid.take(4)}",
                    "profileImageUrl" to "https://picsum.photos/seed/${user.uid}/150/150",
                    "followersCount" to 0,
                    "followingCount" to 0,
                    "bio" to "New to PicConnect!",
                    "phone" to phone
                )
                userRef.set(userData).await()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun uploadPost(uri: Uri, caption: String, onProgress: (Float) -> Unit): Result<String> {
        return try {
            val user = auth.currentUser ?: throw Exception("Not authenticated")
            val postId = UUID.randomUUID().toString()
            val imageRef = storage.reference.child("posts/$postId.jpg")
            
            imageRef.putFile(uri).await()
            val downloadUrl = imageRef.downloadUrl.await().toString()
            
            val postData = mapOf(
                "id" to postId,
                "imageUrl" to downloadUrl,
                "caption" to caption,
                "uploaderId" to user.uid,
                "timestamp" to System.currentTimeMillis(),
                "likeCount" to 0
            )
            firestore.collection("posts").document(postId).set(postData).await()
            
            Result.success(postId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun toggleLike(postId: String, isLiked: Boolean) {
        val user = auth.currentUser ?: return
        val doc = firestore.collection("posts").document(postId)
        
        try {
            firestore.runTransaction { transaction ->
                val snapshot = transaction.get(doc)
                if (snapshot.exists()) {
                    val currentLikes = snapshot.getLong("likeCount") ?: 0
                    val newLikes = if (isLiked) currentLikes + 1 else currentLikes - 1
                    transaction.update(doc, "likeCount", newLikes.coerceAtLeast(0))
                }
            }
            
            val userLiked = firestore.collection("users").document(user.uid).collection("likedPosts").document(postId)
            if (isLiked) userLiked.set(mapOf("timestamp" to System.currentTimeMillis()))
            else userLiked.delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleFollow(targetUserId: String, isFollowing: Boolean) {
        val myId = auth.currentUser?.uid ?: return
        if (myId == targetUserId) return
        
        try {
            val myFollowingRef = firestore.collection("users").document(myId).collection("following").document(targetUserId)
            val targetFollowersRef = firestore.collection("users").document(targetUserId).collection("followers").document(myId)
            
            if (isFollowing) {
                myFollowingRef.set(mapOf("timestamp" to System.currentTimeMillis()))
                targetFollowersRef.set(mapOf("timestamp" to System.currentTimeMillis()))
            } else {
                myFollowingRef.delete()
                targetFollowersRef.delete()
            }
            
            // Note: In production you'd want to use a cloud function or transaction to update counts securely.
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun initFirebaseData() {
        if (isInitialized) return
        isInitialized = true
        
        try {
            val user = auth.currentUser ?: return
            
            // 1. Listen to users
            firestore.collection("users").addSnapshotListener { userSnapshot, _ ->
                if (userSnapshot != null) {
                    val parsedUsers = userSnapshot.documents.map { doc ->
                        UserProfile(
                            id = doc.id,
                            name = doc.getString("name") ?: "Unknown",
                            handle = doc.getString("handle") ?: "",
                            profileImageUrl = doc.getString("profileImageUrl") ?: "https://picsum.photos/200",
                            followersCount = doc.getLong("followersCount")?.toInt() ?: 0,
                            followingCount = doc.getLong("followingCount")?.toInt() ?: 0,
                            bio = doc.getString("bio") ?: ""
                        )
                    }
                    val usersMap = parsedUsers.associateBy { it.id }
                    
                    mockUsers.clear()
                    mockUsers.addAll(parsedUsers)
                    
                    usersMap[user.uid]?.let { currentUserProfile = it }
                    
                    // Update posts with new user info
                    val currentPosts = mockPosts.toList()
                    if (currentPosts.isNotEmpty()) {
                        val updatedPosts = currentPosts.map { post ->
                            val u = usersMap[post.uploaderId]
                            if (u != null) {
                                post.copy(userProfile = u)
                            } else post
                        }
                        mockPosts.clear()
                        mockPosts.addAll(updatedPosts)
                    }
                }
            }
            
            // 2. Listen to following status
            var followingIds = emptyList<String>()
            firestore.collection("users").document(user.uid).collection("following").addSnapshotListener { followingSnap, _ ->
                if (followingSnap != null) {
                    followingIds = followingSnap.documents.map { it.id }
                    
                    val currentUsers = mockUsers.toList()
                    if (currentUsers.isNotEmpty()) {
                        val updatedUsers = currentUsers.map { u ->
                            val isFollowing = followingIds.contains(u.id)
                            if (u.isFollowing != isFollowing) u.copy(isFollowing = isFollowing) else u
                        }
                        mockUsers.clear()
                        mockUsers.addAll(updatedUsers)
                    }
                }
            }
            
            // 3. Listen to liked posts
            var likedIds = emptyList<String>()
            firestore.collection("users").document(user.uid).collection("likedPosts").addSnapshotListener { likesSnapshot, _ ->
                if (likesSnapshot != null) {
                    likedIds = likesSnapshot.documents.map { it.id }
                    
                    // Update current posts with like status
                    val currentPosts = mockPosts.toList()
                    if (currentPosts.isNotEmpty()) {
                        val updatedPosts = currentPosts.map { post ->
                            val isLiked = likedIds.contains(post.id)
                            if (post.isLiked != isLiked) post.copy(isLiked = isLiked) else post
                        }
                        mockPosts.clear()
                        mockPosts.addAll(updatedPosts)
                    }
                }
            }
            
            // 4. Listen to posts
            firestore.collection("posts").addSnapshotListener { postSnapshot, _ ->
                if (postSnapshot != null) {
                    val usersMap = mockUsers.associateBy { it.id }
                    val parsedPosts = postSnapshot.documents.map { doc ->
                        val uploaderId = doc.getString("uploaderId") ?: ""
                        val userProfile = usersMap[uploaderId] ?: UserProfile(id = uploaderId, name = "Unknown")
                        val postId = doc.getString("id") ?: doc.id
                        Post(
                            id = postId,
                            imageUrl = doc.getString("imageUrl") ?: "",
                            caption = doc.getString("caption") ?: "",
                            uploaderId = uploaderId,
                            timestamp = doc.getLong("timestamp") ?: 0L,
                            likeCount = doc.getLong("likeCount")?.toInt() ?: 0,
                            isLiked = likedIds.contains(postId),
                            userProfile = userProfile
                        )
                    }.sortedByDescending { it.timestamp }
                    
                    mockPosts.clear()
                    mockPosts.addAll(parsedPosts)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
