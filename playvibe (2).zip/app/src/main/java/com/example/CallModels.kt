package com.example

data class CallData(
    val id: String = "",
    val callerId: String = "",
    val receiverId: String = "",
    val isVideo: Boolean = false,
    val status: String = "", // "calling", "accepted", "declined", "ended"
    val offer: String = "",
    val answer: String = ""
)

data class IceCandidateData(
    val sdp: String = "",
    val sdpMLineIndex: Int = 0,
    val sdpMid: String = "",
    val type: String = "" // "offer" or "answer"
)
