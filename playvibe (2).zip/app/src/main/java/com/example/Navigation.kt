package com.example

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Home)
    object Upload : Screen("upload", "Post", Icons.Filled.AddCircleOutline)
    object You : Screen("you", "Profile", Icons.Filled.Person)
}

val BottomNavScreens = listOf(
    Screen.Home,
    Screen.Upload,
    Screen.You
)
