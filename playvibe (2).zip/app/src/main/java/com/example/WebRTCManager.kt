package com.example

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import org.webrtc.*

object WebRTCManager {
    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var rootEglBase: EglBase? = null
    private var localVideoTrack: VideoTrack? = null
    private var remoteVideoTrack: VideoTrack? = null
    private var localAudioTrack: AudioTrack? = null
    private var videoCapturer: VideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    val isMicrophoneMuted = MutableStateFlow(false)
    val isCameraEnabled = MutableStateFlow(true)
    val isSpeakerOn = MutableStateFlow(false)

    var onAddRemoteStream: ((VideoTrack) -> Unit)? = null
    var onRemoveRemoteStream: (() -> Unit)? = null
    var onIceCandidate: ((IceCandidate) -> Unit)? = null

    fun init(context: Context) {
        if (peerConnectionFactory != null) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(true)
                .createInitializationOptions()
        )
        rootEglBase = EglBase.create()
        val options = PeerConnectionFactory.Options()
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setOptions(options)
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(rootEglBase?.eglBaseContext))
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(rootEglBase?.eglBaseContext, true, true))
            .createPeerConnectionFactory()
    }

    fun getEglContext() = rootEglBase?.eglBaseContext

    fun startLocalVideo(context: Context, localRenderer: SurfaceViewRenderer) {
        val factory = peerConnectionFactory ?: return
        localRenderer.init(rootEglBase?.eglBaseContext, null)
        localRenderer.setMirror(true)

        videoCapturer = createCameraCapturer(context)
        surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", rootEglBase?.eglBaseContext)
        val videoSource = factory.createVideoSource(videoCapturer!!.isScreencast)
        videoCapturer?.initialize(surfaceTextureHelper, context, videoSource.capturerObserver)
        videoCapturer?.startCapture(1024, 720, 30)

        localVideoTrack = factory.createVideoTrack("100", videoSource)
        localVideoTrack?.addSink(localRenderer)
    }

    fun startLocalAudio() {
        val factory = peerConnectionFactory ?: return
        val audioSource = factory.createAudioSource(MediaConstraints())
        localAudioTrack = factory.createAudioTrack("101", audioSource)
    }

    private fun createCameraCapturer(context: Context): VideoCapturer? {
        val enumerator = Camera2Enumerator(context)
        val deviceNames = enumerator.deviceNames
        for (deviceName in deviceNames) {
            if (enumerator.isFrontFacing(deviceName)) {
                return enumerator.createCapturer(deviceName, null)
            }
        }
        for (deviceName in deviceNames) {
            if (enumerator.isBackFacing(deviceName)) {
                return enumerator.createCapturer(deviceName, null)
            }
        }
        return null
    }

    fun createPeerConnection() {
        val rtcConfig = PeerConnection.RTCConfiguration(
            listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        )
        peerConnection = peerConnectionFactory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate?.let { onIceCandidate?.invoke(it) }
            }
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {
                if (stream?.videoTracks?.isNotEmpty() == true) {
                    remoteVideoTrack = stream.videoTracks[0]
                    onAddRemoteStream?.invoke(remoteVideoTrack!!)
                }
            }
            override fun onRemoveStream(p0: MediaStream?) {
                onRemoveRemoteStream?.invoke()
            }
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })

        localVideoTrack?.let { peerConnection?.addTrack(it, listOf("mediaStream")) }
        localAudioTrack?.let { peerConnection?.addTrack(it, listOf("mediaStream")) }
    }

    fun createOffer(onOfferCreated: (SessionDescription) -> Unit) {
        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription?) {
                desc?.let {
                    peerConnection?.setLocalDescription(this, it)
                    onOfferCreated(it)
                }
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(p0: String?) {}
            override fun onSetFailure(p0: String?) {}
        }, MediaConstraints())
    }

    fun handleOffer(offerSdp: String, onAnswerCreated: (SessionDescription) -> Unit) {
        peerConnection?.setRemoteDescription(object : SdpObserver {
            override fun onCreateSuccess(p0: SessionDescription?) {}
            override fun onSetSuccess() {
                peerConnection?.createAnswer(object : SdpObserver {
                    override fun onCreateSuccess(desc: SessionDescription?) {
                        desc?.let {
                            peerConnection?.setLocalDescription(this, it)
                            onAnswerCreated(it)
                        }
                    }
                    override fun onSetSuccess() {}
                    override fun onCreateFailure(p0: String?) {}
                    override fun onSetFailure(p0: String?) {}
                }, MediaConstraints())
            }
            override fun onCreateFailure(p0: String?) {}
            override fun onSetFailure(p0: String?) {}
        }, SessionDescription(SessionDescription.Type.OFFER, offerSdp))
    }

    fun handleAnswer(answerSdp: String) {
        peerConnection?.setRemoteDescription(object : SdpObserver {
            override fun onCreateSuccess(p0: SessionDescription?) {}
            override fun onSetSuccess() {}
            override fun onCreateFailure(p0: String?) {}
            override fun onSetFailure(p0: String?) {}
        }, SessionDescription(SessionDescription.Type.ANSWER, answerSdp))
    }

    fun addIceCandidate(candidate: IceCandidate) {
        peerConnection?.addIceCandidate(candidate)
    }

    fun toggleMicrophone() {
        val muted = !isMicrophoneMuted.value
        localAudioTrack?.setEnabled(!muted)
        isMicrophoneMuted.value = muted
    }

    fun toggleCamera() {
        val enabled = !isCameraEnabled.value
        localVideoTrack?.setEnabled(enabled)
        isCameraEnabled.value = enabled
    }

    fun close() {
        videoCapturer?.stopCapture()
        videoCapturer?.dispose()
        peerConnection?.close()
        surfaceTextureHelper?.dispose()
        peerConnectionFactory?.dispose()
        rootEglBase?.release()
        
        peerConnection = null
        videoCapturer = null
        peerConnectionFactory = null
        rootEglBase = null
    }
}
