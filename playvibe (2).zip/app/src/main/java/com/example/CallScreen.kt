package com.example

import android.Manifest
import android.content.Context
import android.media.AudioManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

@Composable
fun CallScreen(
    peerId: String,
    isVideo: Boolean,
    isIncoming: Boolean,
    callId: String?,
    onEndCall: () -> Unit
) {
    val context = LocalContext.current
    val myId = FirebaseManager.auth.currentUser?.uid ?: return
    val db = FirebaseManager.firestore
    
    var callStatus by remember { mutableStateOf(if (isIncoming) "incoming" else "calling") }
    var currentCallId by remember { mutableStateOf(callId ?: "${myId}_${System.currentTimeMillis()}") }
    
    val localRenderer = remember { SurfaceViewRenderer(context) }
    val remoteRenderer = remember { SurfaceViewRenderer(context) }
    
    val isMicMuted by WebRTCManager.isMicrophoneMuted.collectAsState()
    val isCamEnabled by WebRTCManager.isCameraEnabled.collectAsState()
    val isSpeakerOn by WebRTCManager.isSpeakerOn.collectAsState()
    
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    
    val peerProfile = mockUsers.find { it.id == peerId } ?: UserProfile("unknown", "Unknown")

    DisposableEffect(Unit) {
        WebRTCManager.init(context)
        WebRTCManager.createPeerConnection()
        
        if (isVideo) {
            WebRTCManager.startLocalVideo(context, localRenderer)
            remoteRenderer.init(WebRTCManager.getEglContext(), null)
        }
        WebRTCManager.startLocalAudio()
        
        WebRTCManager.onAddRemoteStream = { videoTrack ->
            if (isVideo) {
                videoTrack.addSink(remoteRenderer)
            }
        }
        
        WebRTCManager.onIceCandidate = { candidate ->
            val type = if (isIncoming) "answer" else "offer"
            db.collection("calls").document(currentCallId).collection("candidates").add(
                IceCandidateData(candidate.sdp, candidate.sdpMLineIndex, candidate.sdpMid, type)
            )
        }
        
        if (!isIncoming) {
            // I am the caller
            WebRTCManager.createOffer { offer ->
                val callData = CallData(
                    id = currentCallId,
                    callerId = myId,
                    receiverId = peerId,
                    isVideo = isVideo,
                    status = "calling",
                    offer = offer.description
                )
                db.collection("calls").document(currentCallId).set(callData)
            }
        }
        
        // Listen to call doc
        val callDocListener = db.collection("calls").document(currentCallId).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) {
                val callData = snap.toObject(CallData::class.java)
                if (callData != null) {
                    callStatus = callData.status
                    
                    if (!isIncoming && callData.status == "accepted" && callData.answer.isNotEmpty()) {
                        // Caller receives answer
                        WebRTCManager.handleAnswer(callData.answer)
                    }
                    
                    if (callData.status == "ended" || callData.status == "declined") {
                        onEndCall()
                    }
                }
            }
        }
        
        // Listen to ICE candidates
        val candidatesListener = db.collection("calls").document(currentCallId).collection("candidates")
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    for (doc in snap.documentChanges) {
                        if (doc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                            val candidateData = doc.document.toObject(IceCandidateData::class.java)
                            val expectedType = if (isIncoming) "offer" else "answer"
                            if (candidateData.type == expectedType) {
                                WebRTCManager.addIceCandidate(
                                    IceCandidate(candidateData.sdpMid, candidateData.sdpMLineIndex, candidateData.sdp)
                                )
                            }
                        }
                    }
                }
            }

        onDispose {
            callDocListener.remove()
            candidatesListener.remove()
            if (callStatus != "ended" && callStatus != "declined") {
                db.collection("calls").document(currentCallId).update("status", "ended")
            }
            WebRTCManager.close()
            audioManager.isSpeakerphoneOn = false
            localRenderer.release()
            remoteRenderer.release()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (callStatus == "incoming") {
            // Incoming Call UI
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                AsyncImage(
                    model = peerProfile.profileImageUrl,
                    contentDescription = null,
                    modifier = Modifier.size(150.dp).clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.height(32.dp))
                Text(peerProfile.name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(if (isVideo) "Incoming Video Call" else "Incoming Voice Call", color = Color.Gray, fontSize = 18.sp)
                
                Spacer(modifier = Modifier.weight(1f))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    FloatingActionButton(
                        onClick = { 
                            db.collection("calls").document(currentCallId).update("status", "declined")
                            onEndCall()
                        },
                        containerColor = Color.Red,
                        contentColor = Color.White,
                        shape = CircleShape
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = "Decline")
                    }
                    
                    FloatingActionButton(
                        onClick = {
                            callStatus = "accepted"
                            db.collection("calls").document(currentCallId).get().addOnSuccessListener { snap ->
                                val callData = snap.toObject(CallData::class.java)
                                if (callData != null && callData.offer.isNotEmpty()) {
                                    WebRTCManager.handleOffer(callData.offer) { answer ->
                                        db.collection("calls").document(currentCallId).update(
                                            mapOf("status" to "accepted", "answer" to answer.description)
                                        )
                                    }
                                }
                            }
                        },
                        containerColor = Color.Green,
                        contentColor = Color.White,
                        shape = CircleShape
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = "Accept")
                    }
                }
            }
        } else {
            // Ongoing Call UI
            if (isVideo && callStatus == "accepted") {
                AndroidView(
                    factory = { remoteRenderer },
                    modifier = Modifier.fillMaxSize()
                )
            }
            
            if (isVideo) {
                AndroidView(
                    factory = { localRenderer },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .size(120.dp, 160.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            }
            
            if (callStatus == "calling") {
                Column(
                    modifier = Modifier.fillMaxSize().padding(top = 100.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AsyncImage(
                        model = peerProfile.profileImageUrl,
                        contentDescription = null,
                        modifier = Modifier.size(120.dp).clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(peerProfile.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Calling...", color = Color.Gray, fontSize = 16.sp)
                }
            }
            
            // Call Controls
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { WebRTCManager.toggleMicrophone() }) {
                    Icon(if (isMicMuted) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = "Mute", tint = Color.White)
                }
                if (isVideo) {
                    IconButton(onClick = { WebRTCManager.toggleCamera() }) {
                        Icon(if (isCamEnabled) Icons.Filled.Videocam else Icons.Filled.VideocamOff, contentDescription = "Camera", tint = Color.White)
                    }
                }
                IconButton(onClick = { 
                    val newSpeakerState = !isSpeakerOn
                    WebRTCManager.isSpeakerOn.value = newSpeakerState
                    audioManager.isSpeakerphoneOn = newSpeakerState
                }) {
                    Icon(if (isSpeakerOn) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff, contentDescription = "Speaker", tint = Color.White)
                }
                
                FloatingActionButton(
                    onClick = { 
                        db.collection("calls").document(currentCallId).update("status", "ended")
                        onEndCall()
                    },
                    containerColor = Color.Red,
                    contentColor = Color.White,
                    shape = CircleShape
                ) {
                    Icon(Icons.Filled.CallEnd, contentDescription = "End Call")
                }
            }
        }
    }
}
