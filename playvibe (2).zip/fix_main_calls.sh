#!/bin/bash
sed -i '/val currentRoute = navBackStackEntry?.destination?.route/a \
    val myId = FirebaseManager.auth.currentUser?.uid ?: ""\
    LaunchedEffect(myId) {\
        if (myId.isNotEmpty()) {\
            FirebaseManager.firestore.collection("calls")\
                .whereEqualTo("receiverId", myId)\
                .whereEqualTo("status", "calling")\
                .addSnapshotListener { snap, _ ->\
                    if (snap != null && snap.documents.isNotEmpty()) {\
                        val callDoc = snap.documents.first()\
                        val callerId = callDoc.getString("callerId") ?: ""\
                        val isVideo = callDoc.getBoolean("isVideo") ?: false\
                        val callId = callDoc.id\
                        navController.navigate("call_incoming/$callerId/$isVideo/$callId")\
                    }\
                }\
        }\
    }\
' app/src/main/java/com/example/MainActivity.kt

sed -i '/composable("chat\/{channelId}") { backStackEntry ->/i \
            composable("call/{peerId}/{isVideo}") { backStackEntry ->\
                val peerId = backStackEntry.arguments?.getString("peerId") ?: ""\
                val isVideo = backStackEntry.arguments?.getString("isVideo")?.toBoolean() ?: false\
                CallScreen(\
                    peerId = peerId,\
                    isVideo = isVideo,\
                    isIncoming = false,\
                    callId = null,\
                    onEndCall = { navController.navigateUp() }\
                )\
            }\
            composable("call_incoming/{peerId}/{isVideo}/{callId}") { backStackEntry ->\
                val peerId = backStackEntry.arguments?.getString("peerId") ?: ""\
                val isVideo = backStackEntry.arguments?.getString("isVideo")?.toBoolean() ?: false\
                val callId = backStackEntry.arguments?.getString("callId")\
                CallScreen(\
                    peerId = peerId,\
                    isVideo = isVideo,\
                    isIncoming = true,\
                    callId = callId,\
                    onEndCall = { navController.navigateUp() }\
                )\
            }\
' app/src/main/java/com/example/MainActivity.kt
