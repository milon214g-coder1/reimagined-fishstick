#!/bin/bash
sed -i 's/onEditProfileClick = {/onMessageClick = { navController.navigate("chat\/$channelId") },\n                    onEditProfileClick = {/g' app/src/main/java/com/example/MainActivity.kt
