#!/bin/bash
sed -i '/composable("edit_profile") {/i \
            composable("chat/{channelId}") { backStackEntry ->\
                val channelId = backStackEntry.arguments?.getString("channelId") ?: ""\
                ChatScreen(\
                    channelId = channelId,\
                    onNavigateUp = { navController.navigateUp() },\
                    onCallClick = { isVideo ->\
                        navController.navigate("call/$channelId/$isVideo")\
                    }\
                )\
            }\
' app/src/main/java/com/example/MainActivity.kt
