package com.milon.gitajyoti;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;

    private ValueCallback<Uri[]> fileUploadCallback;
    private String cameraCaptureUri;
    private static final int FILE_CHOOSER_REQUEST = 5173;
    private static final int PERMS_REQUEST = 9021;

    // Popup WebView used for Firebase signInWithPopup (Google login)
    private Dialog popupDialog;

    private WebViewAssetLoader assetLoader;

    // ইউটিউব ভিডিও ফুলস্ক্রিনে চালানোর জন্য দরকার (HTML5 video fullscreen API)।
    // এগুলো ছাড়া WebView-এর ভেতরে embed করা ইউটিউব ভিডিও প্লে না হয়ে
    // কালো স্ক্রিন দেখাতে পারে বা ফুলস্ক্রিন বাটনে কাজ করে না।
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private int originalOrientation;
    private ViewGroup fullscreenContainer;
    private static final android.widget.FrameLayout.LayoutParams FULLSCREEN_LAYOUT_PARAMS =
            new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        requestRuntimePermissions();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setGeolocationEnabled(true);
        // Helps Google Sign-In accept the WebView as a normal mobile Chrome browser.
        // Firebase/Google detects embedded WebViews via the "; wv)" marker in the
        // default user agent and blocks signInWithPopup/signInWithRedirect with
        // "auth/operation-not-supported-in-this-environment" when it's present.
        // Removing that marker lets Google Sign-In popups work correctly.
        String ua = settings.getUserAgentString();
        ua = ua.replace("; wv)", ")");
        settings.setUserAgentString(ua + " Chrome/124.0.0.0 Mobile Safari/537.36");

        // Serves files from app/src/main/assets/ under a proper https-like origin
        // (https://appassets.androidplatform.net/assets/...) instead of file://.
        // Firebase Auth (including signInWithPopup) and localStorage need a real
        // http(s) origin to work reliably — file:// often breaks them silently.
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        // JS থেকে সরাসরি ইউটিউব/ফেসবুক/টিকটক ইত্যাদি এক্সটার্নাল লিংক ওপেন করার জন্য ব্রিজ।
        // window.open() ব্যবহার করলে সেটা নতুন WebView পপআপে (onCreateWindow) খুলে যায় —
        // যেটা Google সাইন-ইনের জন্য দরকার হলেও ইউটিউব/ফেসবুক/টিকটকের ক্ষেত্রে সঠিকভাবে
        // কাজ করে না। এই ব্রিজটি সরাসরি Intent.ACTION_VIEW চালিয়ে ফোনে ইনস্টল করা
        // ইউটিউব/ফেসবুক/টিকটক অ্যাপে (থাকলে) বা ব্রাউজারে সরাসরি নিয়ে যায়।
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void openExternalLink(String url) {
                runOnUiThread(() -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) { }
                });
            }
        }, "AndroidBridge");

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progressBar.setVisibility(android.view.View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(android.view.View.GONE);
                swipeRefresh.setRefreshing(false);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("https://appassets.androidplatform.net/")) {
                    // Internal app navigation — let the asset loader handle it.
                    return false;
                }
                if (url.startsWith("mailto:") || url.startsWith("tel:") || url.startsWith("intent:")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) { }
                    return true;
                }
                // Allow external https/http links (e.g. Google OAuth) to load
                // normally in this same WebView/popup so sign-in flows complete.
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            // ইউটিউব ভিডিওর ফুলস্ক্রিন বাটনে চাপলে এটি কল হয় — পুরো স্ক্রিন জুড়ে
            // ভিডিওটা দেখানো হয়, ছাড়া এই অংশ বাদ দিলে ফুলস্ক্রিনে গেলে ভিডিও
            // কালো হয়ে যায় বা আটকে থাকে।
            @Override
            public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                originalOrientation = getRequestedOrientation();

                fullscreenContainer = (ViewGroup) getWindow().getDecorView();
                fullscreenContainer.addView(customView, FULLSCREEN_LAYOUT_PARAMS);

                getWindow().getDecorView().setSystemUiVisibility(
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

                webView.setVisibility(View.GONE);
                setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;

                webView.setVisibility(View.VISIBLE);
                fullscreenContainer.removeView(customView);
                customView = null;

                getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_VISIBLE);
                setRequestedOrientation(originalOrientation);

                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                    customViewCallback = null;
                }
            }

            // Handles <input type="file"> for video/image uploads (with camera capture option).
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                              FileChooserParams params) {
                fileUploadCallback = callback;

                Intent contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = params.getAcceptTypes();
                String mimeType = (types != null && types.length > 0 && types[0].length() > 0)
                        ? types[0] : "*/*";
                contentIntent.setType(mimeType);

                Intent chooser = Intent.createChooser(contentIntent, "ফাইল নির্বাচন করুন");

                // Add a camera-capture option for image inputs.
                if (mimeType.startsWith("image/")) {
                    try {
                        File photoFile = File.createTempFile(
                                "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()),
                                ".jpg", getExternalCacheDir());
                        cameraCaptureUri = photoFile.getAbsolutePath();
                        Uri photoUri = FileProvider.getUriForFile(MainActivity.this,
                                getApplicationContext().getPackageName() + ".fileprovider", photoFile);
                        Intent camIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                        camIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, photoUri);
                        camIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camIntent});
                    } catch (Exception ignored) { }
                }

                try {
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    fileUploadCallback = null;
                    return false;
                }
                return true;
            }

            // Supports Firebase's signInWithPopup(GoogleAuthProvider) — opens a child WebView.
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                           android.os.Message resultMsg) {
                WebView popupWebView = new WebView(MainActivity.this);
                popupWebView.getSettings().setJavaScriptEnabled(true);
                popupWebView.getSettings().setDomStorageEnabled(true);
                popupWebView.getSettings().setUserAgentString(view.getSettings().getUserAgentString());
                popupWebView.getSettings().setSupportMultipleWindows(true);
                popupWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);

                popupDialog = new Dialog(MainActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                popupDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                popupDialog.setContentView(popupWebView);
                popupDialog.setOnDismissListener(d -> popupDialog = null);

                popupWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest request) {
                        return false;
                    }
                });
                popupWebView.setWebChromeClient(new WebChromeClient() {
                    @Override
                    public void onCloseWindow(WebView window) {
                        if (popupDialog != null) {
                            popupDialog.dismiss();
                        }
                    }
                });

                android.webkit.WebView.WebViewTransport transport =
                        (android.webkit.WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popupWebView);
                resultMsg.sendToTarget();

                popupDialog.show();
                return true;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) { }
        });

        swipeRefresh.setOnRefreshListener(() -> webView.reload());
        swipeRefresh.setColorSchemeResources(android.R.color.holo_orange_dark);

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        // If the line above ever fails on an older device, use the local asset path instead:
        // webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestRuntimePermissions() {
        String[] perms;
        if (Build.VERSION.SDK_INT >= 33) {
            perms = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
            };
        } else {
            perms = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
        }
        boolean needed = false;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needed = true;
                break;
            }
        }
        if (needed) {
            ActivityCompat.requestPermissions(this, perms, PERMS_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (fileUploadCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data == null || data.getData() == null) {
                    // Came from the camera-capture intent.
                    if (cameraCaptureUri != null) {
                        results = new Uri[]{Uri.fromFile(new File(cameraCaptureUri))};
                    }
                } else {
                    results = new Uri[]{data.getData()};
                }
            }
            fileUploadCallback.onReceiveValue(results);
            fileUploadCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            webView.getWebChromeClient().onHideCustomView();
            return;
        }
        if (popupDialog != null) {
            popupDialog.dismiss();
            return;
        }
        // অ্যাপটি একটি সিঙ্গেল-পেজ JS অ্যাপ (URL/history পরিবর্তন হয় না বলে
        // webView.canGoBack() প্রায় সবসময় false থাকে), তাই সরাসরি WebView history
        // দিয়ে ব্যাক হ্যান্ডেল করলে প্রথম ব্যাক চাপেই অ্যাপ বন্ধ হয়ে যেত।
        // এখন প্রথমে JS-কে জিজ্ঞাসা করা হয় সে নিজে ভেতরের পেজ-হিস্ট্রি/মোডাল
        // দিয়ে ব্যাক হ্যান্ডেল করতে পারবে কিনা।
        webView.evaluateJavascript(
                "(function(){try{return window.appHandleBackPress ? window.appHandleBackPress() : false;}catch(e){return false;}})()",
                value -> {
                    boolean handledInApp = "true".equals(value);
                    if (!handledInApp) {
                        if (webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            finish();
                        }
                    }
                });
    }
}
