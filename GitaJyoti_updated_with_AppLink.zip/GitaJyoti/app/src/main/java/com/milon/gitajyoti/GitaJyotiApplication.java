package com.milon.gitajyoti;

import android.app.Application;

public class GitaJyotiApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
